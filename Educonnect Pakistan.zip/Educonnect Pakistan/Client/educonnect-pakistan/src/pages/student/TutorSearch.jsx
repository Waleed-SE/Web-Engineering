import React, { useState, useEffect } from "react";
import TutorList from "../../components/tutors/TutorList"; // Import tutor list component
import "../../assets/css/TutorSearch.css"; // Import CSS
import { API } from "../../utils/Api"; // Import dynamic API paths

const TutorSearch = () => {
  const [filters, setFilters] = useState({
    subject: "",
    rating: "",
    day: "",
    time: "",
    period: "",
    minPrice: "", // Add min price to filters
    maxPrice: "", // Add max price to filters
  }); // Separate filters
  const [tutors, setTutors] = useState([]); // List of tutors

  // Fetch Tutors Data from API
  const fetchTutors = async (updatedFilters) => {
    try {
      const { subject, rating, day, time, period, minPrice, maxPrice } =
        updatedFilters;
      const response = await fetch(
        `${API.tutors.getTutors}?subject=${subject}&rating=${rating}&day=${day}&time=${time}&period=${period}&minPrice=${minPrice}&maxPrice=${maxPrice}`
      ); // Send dynamic query params for availability filtering
      const data = await response.json();
      setTutors(data.tutors); // Update tutor list
    } catch (error) {
      console.error("Error fetching tutors:", error);
    }
  };

  // Handle Filter Change (Triggers API Call)
  const handleFilterChange = (e) => {
    const updatedFilters = { ...filters, [e.target.name]: e.target.value }; // Update the specific filter
    setFilters(updatedFilters); // Update filters state
    fetchTutors(updatedFilters); // Call API with updated filters
  };

  // Initial fetch when component mounts
  useEffect(() => {
    fetchTutors(filters); // Fetch tutors with initial filters
  }, []); // Run only once on component mount

  return (
    <div className="tutor-search">
      <h1>Search for Tutors</h1>
      <div className="filters">
        {/* Subject Dropdown */}
        <label>
          Subject:
          <select
            name="subject"
            value={filters.subject}
            onChange={handleFilterChange}
          >
            <option value="">All</option>
            <option value="math">Math</option>
            <option value="science">Science</option>
            <option value="english">English</option>
          </select>
        </label>

        {/* Rating Dropdown */}
        <label>
          Rating:
          <select
            name="rating"
            value={filters.rating}
            onChange={handleFilterChange}
          >
            <option value="">All</option>
            <option value="5">5 Stars</option>
            <option value="4">4+ Stars</option>
            <option value="3">3+ Stars</option>
            <option value="2">2+ Stars</option>
            <option value="!">1+ Stars</option>
          </select>
        </label>

        {/* Day Dropdown */}
        <label>
          Day:
          <select name="day" value={filters.day} onChange={handleFilterChange}>
            <option value="">Any</option>
            <option value="Monday">Monday</option>
            <option value="Tuesday">Tuesday</option>
            <option value="Wednesday">Wednesday</option>
            <option value="Thursday">Thursday</option>
            <option value="Friday">Friday</option>
            <option value="Saturday">Saturday</option>
            <option value="Sunday">Sunday</option>
          </select>
        </label>

        {/* Time Dropdown */}
        <label>
          Time:
          <select
            name="time"
            value={filters.time}
            onChange={handleFilterChange}
          >
            <option value="">Any</option>
            <option value="1-2">1-2</option>
            <option value="2-3">2-3</option>
            <option value="3-4">3-4</option>
            <option value="4-5">4-5</option>
            <option value="5-6">5-6</option>
            <option value="6-7">6-7</option>
            <option value="7-8">7-8</option>
            <option value="8=9">8=9</option>
            <option value="9-10">9-10</option>
            <option value="10-11">10-11</option>
            <option value="11-12">11-12</option>
            <option value="12-1">12-1</option>
          </select>
        </label>

        {/* Period Dropdown */}
        <label>
          Period:
          <select
            name="period"
            value={filters.period}
            onChange={handleFilterChange}
          >
            <option value="">Any</option>
            <option value="AM">AM</option>
            <option value="PM">PM</option>
          </select>
        </label>

        {/* Min Price Input */}
        <label>
          Min Price:
          <input
            type="number"
            name="minPrice"
            value={filters.minPrice}
            onChange={handleFilterChange}
            placeholder="Min price"
          />
        </label>

        {/* Max Price Input */}
        <label>
          Max Price:
          <input
            type="number"
            name="maxPrice"
            value={filters.maxPrice}
            onChange={handleFilterChange}
            placeholder="Max price"
          />
        </label>
      </div>
      <TutorList tutors={tutors} /> {/* Pass tutors to TutorList */}
    </div>
  );
};

export default TutorSearch;
