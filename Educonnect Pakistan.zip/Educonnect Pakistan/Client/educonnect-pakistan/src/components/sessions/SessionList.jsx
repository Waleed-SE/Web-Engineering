import React from "react";

const SessionList = ({
  filteredSessions,
  handleViewReschedule,
  handleCancelSession,
}) => {
  return (
    <div>
      {filteredSessions.length === 0 ? (
        <p>No sessions available for this date.</p>
      ) : (
        <ul>
          {filteredSessions.map((session) => (
            <li key={session._id}>
              {session.time} - {session.status} ({session.sessionType})
              <div className="session-actions">
                <button onClick={() => handleViewReschedule(session)}>
                  View / Reschedule
                </button>
                <button
                  onClick={() => handleCancelSession(session._id)}
                  className="delete-btn"
                >
                  Cancel
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SessionList;
