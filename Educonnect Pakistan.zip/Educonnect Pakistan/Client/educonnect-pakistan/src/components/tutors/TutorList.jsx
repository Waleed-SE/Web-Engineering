import React from "react";
import { useNavigate } from "react-router-dom";

const TutorList = ({ tutors }) => {
  const navigate = useNavigate(); // Use navigate hook for redirection

  return (
    <div className="tutor-list">
      <h2>Available Tutors</h2>
      {tutors.length > 0 ? (
        <ul>
          {tutors.map((tutor) => (
            <li key={tutor._id} className="tutor-item">
              {" "}
              {/* Use tutor._id as key */}
              <h3>{tutor.name}</h3>
              <p>Subjects: {tutor.subjects.join(", ")}</p>{" "}
              {/* Display subjects */}
              <p>Rating: {tutor.rating || "N/A"}</p> {/* Display rating */}
              <p>Hourly Rate: ${tutor.hourlyRate || "N/A"}</p>{" "}
              {/* Display hourly rate */}
              <p>Availability:</p>
              <ul>
                {/* Format each availability object */}
                {tutor.availability.map((slot, index) => (
                  <li key={slot._id || index}>
                    {slot.day}, {slot.time} {slot.period}
                  </li>
                ))}
              </ul>
              {/* Book Session Button */}
              <button
                onClick={() =>
                  navigate(`/dashboard/student/book-session/${tutor._id}`)
                } // Pass tutor ID
              >
                Book a Session
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p>No tutors found.</p>
      )}
    </div>
  );
};

export default TutorList;
